<?php
error_reporting(E_ALL);
require_once 'C:\xampp\htdocs\jatinder\bigcomerce\vendor\autoload.php';
require 'bigcommerce/bigcommerce.php';
//echo "hh";
use Bigcommerce\Api\Client as Bigcommerce;
Bigcommerce::configure(array(
	'store_url' => 'https://products3.mybigcommerce.com',
	'username'	=> 'swiftechies',
	'api_key'	=> '8qmkqx7ixm61j53oqtmlp895ykmqj56'
));
$ping = Bigcommerce::getTime();

if ($ping) echo $ping->format('H:i:s');

$products = Bigcommerce::getProducts();
print_r ($products);
foreach($products as $product) {
	echo $product->name;
	echo $product->price;
}

?>

